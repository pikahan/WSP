import {SET_CATEGORY} from '../constants/safetyHazard'

export const setCategory = categoryData => ({
  type: SET_CATEGORY,
  categoryData
})

export function fetchCategory() {
  return dispatch => {
    // TODO fetch Date
    setTimeout(() => {
      dispatch(setCategory([
        {
          id: 0,
          name: '机械安全',
        },
        {
          id: 1,
          name: '烟花爆竹',
        },
        {
          id: 2,
          name: '冶金类',
        },
        {
          id: 3,
          name: '危险化学品管理',
        },
      ]))
    }, 500)
  }
}

