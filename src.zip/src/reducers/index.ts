import { combineReducers } from 'redux'
import counter, {CounterState} from './counter'
import hazard, {HazardState} from './hazard'

export default combineReducers({
  counter,
  hazard
})



export interface RootState {
  counter: CounterState
  hazard: HazardState
}
