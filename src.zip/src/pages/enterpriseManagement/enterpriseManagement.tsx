import Taro, { useState } from '@tarojs/taro'
import './enterpriseManagement.scss'
import AdvancedSearchContent from './advancedSearchContent'
import {EnterpriseFormData} from './advancedSearchContent'
import AdvancedSearchPage from '../../components/advancedSearchPage'
import EnterpriseList from '../../components/enterpriseList'

const fakeEnterpriseData = [
  {
    name: '能力十分有限公司',
    imgSrc: 'http://placehold.it/30x30',
    note: '一个能力十分有限公司'
  },
  {
    name: '能力十分有限公司',
    imgSrc: 'http://placehold.it/30x30',
    note: '一个能力十分有限公司'
  }
]

const EnterpriseManagement = () => {
  const [name, setName] = useState('')
  const initialAdvancedSearchOption: EnterpriseFormData = {
    code: '',
    legalPerson: ''
  }
  const [advancedSearchOption, setAdvancedSearchOption] = useState(initialAdvancedSearchOption)
  const setInputValue = (key, value) => {
    setAdvancedSearchOption({...advancedSearchOption, [key]: value})
  }

  const advancedSearchBtnClick = () => {
    console.log('AdvancedSearchBtnClick')
    console.log(advancedSearchOption)
  }

  const advancedSearchReset = () => {
    console.log('AdvancedSearchBtnClick')
  }

  const searchBtnClick = () => {
    console.log('searchBtnClick')
  }

  const searchContentChange = value => {
    setName(value)
    console.log('searchContentChange')
  }

  return (
    <AdvancedSearchPage
      renderAdvancedSearchContent={<AdvancedSearchContent onValueChange={setInputValue} enterpriseFormData={advancedSearchOption} />}
      renderList={<EnterpriseList enterpriseData={fakeEnterpriseData} />}
      searchContent={name}
      onAdvancedSearchBtnClick={advancedSearchBtnClick}
      onAdvancedSearchReset={advancedSearchReset}
      onSearchBtnClick={searchBtnClick}
      onSearchContentChange={searchContentChange}
      hasFloatBtn={true}
      onFloatBtnClick={() => console.log('onFloatBtnClick')}
    ></AdvancedSearchPage>
  )
}

EnterpriseManagement.config = {
  navigationBarTitleText: '企业管理'
}

export default EnterpriseManagement

