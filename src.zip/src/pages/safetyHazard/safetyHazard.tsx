import Taro, { useState } from '@tarojs/taro'
import './safetyHazard.scss'
import AdvancedSearchContent from './advancedSearchContent'
import {SafetyHazardFormData} from './advancedSearchContent'
import AdvancedSearchPage from '../../components/advancedSearchPage'
import {useDispatch} from '@tarojs/redux'
import useEffect = Taro.useEffect
import {fetchCategory} from '../../actions/hazard'
import HazardList from '../../components/hazardList'

const fakeEnterpriseData = [
  {
    id: 1,
    name: '危险的烟花爆竹',
    note: '烟花爆竹存在严重安全隐患',
    typeName: '烟花爆竹'
  },
  {
    id: 2,
    name: '机械安全问题',
    typeName: '机械安全',
    note: '机械存在严重安全问题'
  }
]

const SafetyHazard = () => {
  const [name, setName] = useState('')
  const initialAdvancedSearchOption: SafetyHazardFormData = {
    safetyHazardLevel: '空',
    type: ''
  }

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchCategory())
  }, [])

  const [advancedSearchOption, setAdvancedSearchOption] = useState(initialAdvancedSearchOption)
  const setInputValue = (key, value) => {
    setAdvancedSearchOption({...advancedSearchOption, [key]: value})
  }

  const advancedSearchBtnClick = () => {
    console.log('AdvancedSearchBtnClick')
    console.log(advancedSearchOption)
  }

  const advancedSearchReset = () => {
    console.log('AdvancedSearchBtnClick')
  }

  const searchBtnClick = () => {
    console.log('searchBtnClick')
  }

  const searchContentChange = value => {
    setName(value)
    console.log('searchContentChange')
  }

  const handleFloatBtnClick = () => {
    Taro.navigateTo({
      url: '/pages/safetyHazardDetail/safetyHazardDetail'
    })  }

  return (
    <AdvancedSearchPage
      renderAdvancedSearchContent={<AdvancedSearchContent onValueChange={setInputValue} safetyHazardFormData={advancedSearchOption} />}
      renderList={<HazardList hazardData={fakeEnterpriseData} />}
      searchContent={name}
      onAdvancedSearchBtnClick={advancedSearchBtnClick}
      onAdvancedSearchReset={advancedSearchReset}
      onSearchBtnClick={searchBtnClick}
      onSearchContentChange={searchContentChange}
      hasFloatBtn={true}
      onFloatBtnClick={handleFloatBtnClick}
    ></AdvancedSearchPage>
  )
}

SafetyHazard.config = {
  navigationBarTitleText: '企业管理'
}

export default SafetyHazard

