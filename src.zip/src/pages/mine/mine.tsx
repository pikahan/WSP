// import Taro, { useState } from '@tarojs/taro'
import Taro from '@tarojs/taro'
import {Button, Image, Text, View} from '@tarojs/components'
import  { AtList, AtListItem } from 'taro-ui'

import './mine.scss'



const Mine = () => {

  return (
    <View className="mine">
      <View className="mine_top">
        <Text className="mine_top-name">
          张三
        </Text>
        <View className="mine_top-image-wrapper">
          <Image
            src={require('../../image/icon.jpg')}
          />
        </View>
      </View>
        <AtList className="mine_list" hasBorder={false}>
          <AtListItem
            title='我的企业'
          />
          <AtListItem
            title='密码修改'
          />
        </AtList>
        <AtList className="mine_list" hasBorder={false}>
          <AtListItem
            title='企业管理'
          />
          <AtListItem
            title='用户管理'
          />
        </AtList>
      <Button type="warn">退出登录</Button>
    </View>
  )
}


export default Mine

