import Taro, { useState, useRouter, useEffect } from '@tarojs/taro'
import './safetyHazardDetail.scss'
import {View, Picker, Text} from '@tarojs/components'
import {AtForm, AtMessage, AtImagePicker, AtInput, AtList, AtListItem, AtInputNumber, AtTextarea, AtButton} from 'taro-ui'
import {useSelector} from '@tarojs/redux'
import {RootState} from '../../reducers'
import HanTitle from '../../components/hanTitle'


const levels = ['重大', '较大', '一般']
const forSafetyHazardLevel = index => {
  return levels[index]
}

const SafetyHazardDetail = () => {
  const [files, setFiles] = useState<any>([])
  const [showAddBtn, setShowAddBtn] = useState(true)

  const handleImageChange = files => {
    console.log(files)
    if (files.length > 3) {
      return Taro.atMessage({
        message: '最多上传三张图片',
        type: 'error'
      })
    } else if (files.length === 3) {
      setShowAddBtn(false)
    } else {
      setShowAddBtn(true)
    }
    setFiles(files)
  }

  const [formData, setFormData] = useState({
    name: '',
    safetyHazardLevel: '',
    typeId: -1,
    description: '',
    measures: '',
    limitTime: 0
  })



  const setFormValue = (key, value) => {
    setFormData({...formData, [key]: value})
  }

  const [safetyHazardLevelIndex, setSafetyHazardLevelIndex] = useState(0)
  const handleSafetyHazardLevelChange = e => {
    setSafetyHazardLevelIndex(e.detail.value*1)
    setFormValue('safetyHazardLevel', forSafetyHazardLevel(safetyHazardLevelIndex))
  }

  const type = useSelector((state: RootState) => state.hazard.hazardCategory)
  const [typeIndex, setTypeIndex] = useState(0)
  const handleTypeChange = e => {
    setTypeIndex(e.detail.value*1)
    setFormValue('typeId', type[typeIndex].id)
  }
  // interface HazardData {
  //   id: number
  //   name: string
  //   safetyHazardLevel: SafetyHazardLevel
  //   typeId: number
  //   description: string
  //   measures: string
  //   limitTime: number
  //   shootingTime: number
  //   shootingPerson: string
  //   location: Array<string>
  //   troubleshooter: string
  //   imageSrcList: Array<string>
  // }

  const handleSubmit = () => {
    console.log(formData)
  }

  let [btnDisabled, setBtnDisabled] = useState(false)

  const router = useRouter()
  useEffect(() => {
    // 路径参数
    console.log(router.params)
    if (typeof router.params.id === 'undefined') {
      return
    }

    setBtnDisabled(true)

    // TODO fetch id
    setFormData({
      name: '危险的烟花爆竹',
      safetyHazardLevel: '较大',
      typeId: 1,
      description: '烟花爆竹存在严重安全隐患',
      measures: '这问题可以这样这样解决',
      limitTime: 3
    })
    setFiles([
      {
        url: 'http://tmp/wx17d81ec7f7b2a1e3.o6zAJswOlwfLV97nS2CNfWwvsnXQ.bRodZmpBydh76dc78df64ddec5d339c993647b1c8968.png',
        file: {
          path: 'http://tmp/wx17d81ec7f7b2a1e3.o6zAJswOlwfLV97nS2CNfWwvsnXQ.bRodZmpBydh76dc78df64ddec5d339c993647b1c8968.png',
          size: 1607
        }
      }
    ])

    // const deleteBtn =


  }, [])



  return (
    <View>
      <AtMessage />
      <AtForm
        onSubmit={handleSubmit}
      >
        <AtInput
          name='name'
          title='风险源名称'
          type='text'
          placeholder='输入风险源名称'
          value={formData.name}
          onChange={value => setFormValue('name', value)}
          disabled={btnDisabled}
        />
        <Picker mode='selector'
                range={levels}
                onChange={handleSafetyHazardLevelChange}
                value={safetyHazardLevelIndex}
                disabled={btnDisabled}
        >
          <AtList>
            <AtListItem
              title='隐患等级'
              extraText={forSafetyHazardLevel(safetyHazardLevelIndex)}
            />
          </AtList>
        </Picker>
        <Picker
          mode='selector'
          range={type}
          rangeKey="name"
          onChange={handleTypeChange}
          value={typeIndex}>
          <AtList>
            <AtListItem
              title='隐患类别'
              extraText={type[typeIndex].name}
            />
          </AtList>
        </Picker>
        <View className="form-input_number">
          <Text>期限天数</Text>
          <AtInputNumber
            disabled={btnDisabled}
            type="number"
            min={0}
            max={30}
            step={1}
            value={formData.limitTime}
            onChange={value => setFormValue('limitTime', value)}
          />
        </View>
        <View className="form-item">
          <View className="form-item-title">
            <HanTitle title="隐患图片"/>
          </View>
          <AtImagePicker
            showAddBtn={!btnDisabled && showAddBtn}
            multiple={true}
            count={3}
            length={3}
            files={files}
            onChange={handleImageChange}
            showDeleteBtn={!btnDisabled}
          />
        </View>

        <View className="form-item">
          <View className="form-item-title">
            <HanTitle title="描述"/>
          </View>
          <View className="form-item-content">

            <AtTextarea
              disabled={btnDisabled}
              value={formData.description}
              onChange={value => setFormValue('description', value)}
              maxLength={200}
              placeholder=''
            />
          </View>
        </View>
        <View className="form-item">
          <View className="form-item-title">
            <HanTitle title="措施"/>
          </View>
          <View className="form-item-content">
            <AtTextarea
              disabled={btnDisabled}
              value={formData.measures}
              onChange={value => setFormValue('measures', value)}
              maxLength={200}
              placeholder=''
            />
          </View>
        </View>
        <View className="form-submit_btn">
          {
            btnDisabled &&
            <AtButton type='primary' formType="submit">添加</AtButton>
          }
        </View>
      </AtForm>
    </View>
  )
}

SafetyHazardDetail.config = {
  navigationBarTitleText: '隐患'
}

export default SafetyHazardDetail

