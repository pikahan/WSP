export const ADD = 'ADD'
export const MINUS = 'MINUS'
export const REQUEST_URL = 'http://10.67.200.146:8081/'
